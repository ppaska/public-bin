(function() {
  chrome.action.onClicked.addListener(function(tab) {
    chrome.tabs.create({'url': chrome.runtime.getURL('index.html')}, function(tab) {
      console.log('Welcome to WORKSHEETS Data Studio - chrome extension');
    });
  });
})()
